
import java.awt.*;

public class Point {
	private int pointX, pointY, pointR;
	private Color color;
		
	public Point(int  pointX, int pointY, int pointR, Color color) {
		this.pointX = pointX;
		this.pointY = pointY;
		this.pointR = pointR;
		this.color = color;
	}
	public int getX() {
		return pointX;
	}
	public int getY() {
		return pointY;
	}
	

	public void drawPoint(Graphics graphic) {
		graphic.setColor(color);
		graphic.fillOval(pointX, pointY, pointR, pointR);
		
	}
	
	public void drawLine(Graphics graphic, int x1, int y1, int x2, int y2) {
		graphic.setColor(color);
		if (x2 == 0 && y2 == 0) {
			x2=x1;
			y2=y1;
			
		}
		Graphics2D g2 = (Graphics2D) graphic;
	    g2.setStroke(new BasicStroke(1));
		g2.drawLine(x1, y1, x2, y2);
		
	}
	public void drawEraserLine(Graphics graphic, int x1, int y1, int x2, int y2) {
		graphic.setColor(Color.white);
		if (x2 == 0 && y2 == 0) {
			x2=x1;
			y2=y1;
			
		}
		Graphics2D g2 = (Graphics2D) graphic;
	    g2.setStroke(new BasicStroke(10));
		g2.drawLine(x1, y1, x2, y2);
		g2.setStroke(new BasicStroke(1));
		
	}
	
	// For draging shapes
	// Use coords of click and coords of mouse release to determine size / width / height
	// Use initial click coords for start point and pos / neg axis movement to determine
	// +/- of width / height
}
