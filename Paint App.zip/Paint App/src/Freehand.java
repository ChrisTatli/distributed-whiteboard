import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Freehand extends Shape   {

	protected Color color = Color.BLACK;
	protected String name;
	protected boolean isFilled;
	protected boolean isDraw;
	private ArrayList<Point> pointList;
	private ArrayList<Point> pointList2;
	private int firstX, lastX, firstY, lastY;

	public Freehand() {
		super();
		color = null;
		name = null;
		pointList = null;
		firstX = 0;
		lastX = 0;
		firstY = 0;
		lastY = 0;
	}
	
	public void setFX(int x) {
		firstX = x;
	}

	public int getFX() {
		return firstX;
	}
	
	public void setLX(int x) {
		lastX = x;
	}

	public int getLX() {
		return lastX;
	}
	
	public void setFY(int y) {
		firstY = y;
	}

	public int getFY() {
		return firstY;
	}
	
	public void setLY(int y) {
		lastY = y;
	}

	public int getLY() {
		return lastY;
	}

	public ArrayList<Point> getPoints() {
		return pointList;
	}

	public void setPoints(ArrayList<Point> pointList) {
		this.pointList= pointList;
	}
	

	@Override
	Shape select(MouseEvent e, ArrayList<Shape> currentShapes, int i) {
		return null;
	}

	@Override
	void move(MouseEvent e, Shape selectedShape) {
		/*int x = e.getX();
		int y = e.getY();
		ArrayList<Point>  points = ((Freehand) selectedShape).getPoints();
		
		for(Point point: points) {
			int x1 =point.getX()+x;
			int y1 =point.getY()+y;
			
			pointList2.add(new Point(x1, y1, 5, color));

		}
		
		((Freehand) selectedShape).setPoints(pointList2);*/
	}

	@Override
	void resize(MouseEvent e, Shape selectedShape) {

	}


	
}
